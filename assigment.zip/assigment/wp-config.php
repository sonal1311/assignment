<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'assigment' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'sbw3*6Pg{O|y`,.f;q:H1{5W;Oc?$W<;,5(N$$&hzf1GP1>}%@ODh4]~Vs2m&}V2' );
define( 'SECURE_AUTH_KEY',  '_t((}uU0 d7l5UOD}9G:9gSkdNK=7Xi7Ebu#r3IZ r6M8%|Qa$PAlGkWO<.-eJ-|' );
define( 'LOGGED_IN_KEY',    '{p=oC]]hAYftnqpd{CZNN5D!69rf-72&%E%As ?x72LY;%VWgvgxG5NDP`hHA=]/' );
define( 'NONCE_KEY',        'Mg,&A3U5j^<<Y5Z[$Gq#T~+{,YO:_2T$pH<g)]!k{i#9XS*IlJ?n8eWs$n8qI^4e' );
define( 'AUTH_SALT',        '2?.6oq~@;by[yP.</W)Tk7$/EffPr:NoP$`B4-:PK5g4Uc(]<jqb|vvbRZM_<X#o' );
define( 'SECURE_AUTH_SALT', '^6t&6e;a-CQd>i2(7d(>Zx? <Iaie#p(GT}&XMg|pnf{TzfWserTEEJ:9%HTk(.?' );
define( 'LOGGED_IN_SALT',   '=djngzV|LW,qD%;n!dbJ|ve$YXUxN*V+Vw`#RxkgKv=sX]U@:Wy^^-E[PlpEyX>P' );
define( 'NONCE_SALT',       'n5nA:P{U%F w#)0;=(tHpO5A0I2SnRX;KgFv($Ab{ Hpp7aUVUqbsnTOnKo4jYB|' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'assigment_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
